package Q4;

public class Lunch  extends Meal{

	@Override
	public void displaymeal() {
	
		
		System.out.println("this is lunch meal");
		
	}

	@Override
	public void displaycost() {
		idk.getcost();
		
		
	}

}
