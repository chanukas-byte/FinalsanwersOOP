package Warsystemcp24;

public class RocketMissileSystem {
	
	
	public void launch(String source)
	{
		
		System.out.println("Rocketmissle is launching");
		
	}
	
	
	
	
	public void blash(String source)
	{
		
		System.out.println("Rocketmissle is blashing");
		
	}


}
