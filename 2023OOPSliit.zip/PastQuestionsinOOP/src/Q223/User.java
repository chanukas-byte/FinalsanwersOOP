package Q223;

public class User implements Runnable  {

	@Override
	public void run() {
		try
		{
		for(int i=0;i<10;i++)
		{
			System.out.println("hello from threads");
			
		}
		 Thread.sleep(10000);
	
		
	}catch(Exception e)
		{
		System.out.println(e.getMessage());
		}

}}
