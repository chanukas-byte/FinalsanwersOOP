package warssytemQ4;

public interface Command {

	
	public void execute();
	
}
