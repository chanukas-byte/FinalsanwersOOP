package warssytemQ4;

public class LaunchMissile  implements MissileOperation{

	@Override
	public void initiateOperation(String location) {
		
		
		
		System.out.println("launch missile is opeation"+location);
	}

}
