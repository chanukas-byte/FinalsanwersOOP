package Q3;

public class EvenOddPrinter {
	
	private static final int MAX_NUM=20;
	private static volatile int nextnum=1;
	private static final Object lock=new Object();
	
	
	
	
	public static void main(String []args)
	{
		
		
		Thread evenThread = new Thread(new EvenRunnable(),"EvenThread");
		Thread oddThread = new Thread(new OddRunnable(),"oddThread");
		
		
		evenThread.start();
		
		
		try
		{
			evenThread.join();
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
			
			
		}
		
		
		oddThread.start();
		
		
		try
		{
			oddThread.join();
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
			
			
		}
		
		
		
		
	}
	
	
	

}
