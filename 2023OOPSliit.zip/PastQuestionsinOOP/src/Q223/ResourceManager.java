package Q223;

public class ResourceManager  implements Runnable {

	@Override
	public void run() {
		
		
	}

	
	
	
}
