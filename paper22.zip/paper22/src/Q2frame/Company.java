package Q2frame;

import java.util.HashMap;

public class Company {

	public static void main(String[] args) {
		
		
	HashMap<Integer,String>emplist=new HashMap<>();
	
	
	Employee<Integer,String>em= new Employee<>(4,"lalith");
	em.display();
	
	
	
	 
	
	

}
}