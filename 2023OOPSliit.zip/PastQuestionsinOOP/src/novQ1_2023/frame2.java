package novQ1_2023;

import java.util.HashMap;

public class frame2 {
	
	HashMap<String,String>Inventory= new HashMap<>();
	
	
	
	

}
