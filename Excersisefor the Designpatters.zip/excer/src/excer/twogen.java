package excer;

public class twogen<T1, T2> {

	
	private T1  ob;
	private T2 os;
	
	
	
	
	public T1 getOb() {
		return ob;
	}




	public void setOb(T1 ob) {
		this.ob = ob;
	}




	public T2 getOs() {
		return os;
	}




	public void setOs(T2 os) {
		this.os = os;
	}




	public twogen(T1 ob, T2 os) {
		super();
		this.ob = ob;
		this.os = os;
	
	}
	
	public void dsiplay()
	{
		System.out.println("first is"+ob);
		System.out.println("second is"+os);
		
	}
}
