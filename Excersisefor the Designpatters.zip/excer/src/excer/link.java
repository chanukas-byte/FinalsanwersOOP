package excer;

import java.util.LinkedHashSet;
import java.util.Set;

public class link {

	public static void main(String[] args) {
		
		
		Set<Integer> bb  = new LinkedHashSet<>();
		
		bb.add(3444);

		bb.add(444);

		bb.add(1444);

		bb.add(4444);

		bb.add(5444);

		bb.add(6444);

		bb.add(7444);
		
		for(Integer v :bb)
		{
			System.out.println(v);
		}
		
		
		
		
		// inserted order
		
		//overriding 
		
		
	}

}
