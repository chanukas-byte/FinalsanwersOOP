package Q12023nov;

import java.util.ArrayList;
import java.util.List;

abstract public class Course {

	 
	 
	
	ArrayList<String>coursed= new ArrayList<>();
	
	String code;
	String coursename;
	public Course(String code, String coursename) {
		super();
		this.code = code;
		this.coursename = coursename;
	}
	
	
	
	public Course() {
		super();
		this.code = "";
		this.coursename ="";
		
	}
	
	
	abstract public void displaycoursedetails();
	
}
