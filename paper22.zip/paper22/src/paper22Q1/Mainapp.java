package paper22Q1;

import java.util.ArrayList;

public class Mainapp {

	public static void main(String[] args) {
		
		ArrayList<Registercustomer> rc = new ArrayList<>();
		
	
		rc.add(new Registercustomer(1,"saman",249.00,3400.00));
		
		//rc.add(new Registercustomer(3,"sanul",219.00,3476.02));
		
		
		
		
		for (Registercustomer rr:rc)
		{
			rr.display();
		}
		
	}

}
