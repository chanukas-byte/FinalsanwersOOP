package Q4;

public class Dinner  extends Meal{

	@Override
	public void displaymeal() {
		System.out.println("this is dinner meal");
		
		
	}

	@Override
	public void displaycost() {
		
		
		idk.getcost();
		
	}

}
