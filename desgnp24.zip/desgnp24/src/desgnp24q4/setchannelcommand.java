package desgnp24q4;

public class setchannelcommand implements Command {

	 
	Tv tv;
	
	
	
	
	public setchannelcommand(Tv tv) {
		super();
		this.tv = tv;
	}




	@Override
	public void execute() {
		
           tv.setchannel(0);
		
	}

}
