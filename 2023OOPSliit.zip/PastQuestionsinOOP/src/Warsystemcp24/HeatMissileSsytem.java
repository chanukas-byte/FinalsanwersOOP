package Warsystemcp24;

public class HeatMissileSsytem {
	
	
	private static HeatMissileSsytem instance= null;
	
	private HeatMissileSsytem()
	{
		System.out.println("HeatMissile System Intilaizing");
		
	}
	
	
	public static HeatMissileSsytem getinstance()
	
	{
		if(instance==null)
		{
			synchronized(HeatMissileSsytem.class)
			{
				if(instance==null)
				{
					instance= new HeatMissileSsytem();
					
				}
			}
		}
		{
			
		}
		return instance;
	}
	
	
	
	public void launch(String source)
	{
		System.out.println("Heat Misssile is launching");
		
	}

	
	
	public void blast(String locations)
	{
		System.out.println("heatmissile system blasting");
		
	}
}
