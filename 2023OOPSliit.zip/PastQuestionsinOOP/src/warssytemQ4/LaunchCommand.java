package warssytemQ4;

public class LaunchCommand implements  Command{

	 MissileSystem missilesystem ;
	String Source;
	 
	
	
	
	
	
	
	public LaunchCommand(MissileSystem missilesystem, String Source) {
		super();
		this.missilesystem = missilesystem;
		this.Source = Source;
	}







	@Override
	public void execute() {
		
		
		missilesystem.launch(Source);
		
	}
	
	

}
