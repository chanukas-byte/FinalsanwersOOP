package Q4;

public class Breakfast extends Meal {

	@Override
	public void displaymeal() {
		System.out.println("this is breakfast meal");
		
		
	}

	@Override
	public void displaycost() {
		idk.getcost();
	}

}
