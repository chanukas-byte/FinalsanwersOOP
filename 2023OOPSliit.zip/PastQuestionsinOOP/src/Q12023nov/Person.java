package Q12023nov;

public abstract class Person {
	
	int id;
	String name;
	
	//default
	public Person(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	

	public Person() {
		super();
		this.id = 0;
		this.name ="";
		
		
	}

	
	
	abstract public void displaydetails();
	
}
