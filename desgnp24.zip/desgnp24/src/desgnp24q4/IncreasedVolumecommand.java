package desgnp24q4;

public class IncreasedVolumecommand    implements Command {

	
	SoundSystem sd;
	
	public IncreasedVolumecommand(SoundSystem sd) {
		super();
		this.sd = sd;
	}

	@Override
	public void execute() {
		
		sd.increasedvolume();
		
	}

}
