package Q2;

import java.util.ArrayList;
import java.util.Scanner;

public class framework {

	public static void main(String[] args)
	{
	ArrayList<Integer>childs= new ArrayList<>();
	
	
	
	   System.out.println("enter the numbers::");
	   
	    
	   Scanner sc= new Scanner(System.in);
	   int num=sc.nextInt();
	   while(num!=0)
	   {
		
		   
		   
		   if(num%2!=0)
		   {
			   childs.add(num);
			   
		   }
		
		   
		   num=sc.nextInt();
		   
	   }
	   
	   
	   // printing as  ArrayList of odd numbers  details
	      //checking list is empty or not
	     
	        if(childs.isEmpty())
	        {
	        	System.out.println("there no odd numbers given in list");
	        	
	        }
	        else
	        {
	         System.out.println("oddnumbers in list");
	        System.out.println(childs);
	        
	   }
	   
	}
	
}

	  
	 
	   
	   
	   
	
