package Q4;

public abstract class Meal {

	
	IpreparedQuickly ic;
	Ipreparedeliciously idk;
	
	
	
	public void setflavor(	Ipreparedeliciously flavour)
	
	{
		
		this.idk=flavour;
	}
	
	
	

	public void setduration(IpreparedQuickly dura)
	
	{
	       this.ic=dura;
		
	}
	
	public void mealwithflavor()
	{
		if(idk!=null)
		{
			
			idk.addflavour();
			System.out.println("your meal cost is:"+idk.getcost());
			
			
			
		}
	}
	
	
	
	public void  mealinduration()
	{
		if (ic!=null)
		{
		ic.deliverytime();
		
		}
	
	
	
	}
	
	
    abstract public void displaymeal();
    abstract public void displaycost();
    
 
	
}
