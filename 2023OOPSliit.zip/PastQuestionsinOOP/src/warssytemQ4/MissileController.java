package warssytemQ4;

public class MissileController {
	
	   Command launchcommand;
	   Command Blastcommand;
	   
	   
	   
	   
	public MissileController()
	{
		System.out.println("initiliaze the MissleController");
		
	}




	public void setLaunchcommand(Command launchcommand) {
		this.launchcommand = launchcommand;
	}




	public void setBlastcommand(Command blastcommand) {
		Blastcommand = blastcommand;
	}
	   
	   
	
	public void launchmissile()
	{
		launchcommand.execute();
		
	}
	   
	public void blastmissile()
	{
		Blastcommand.execute();
	}
	

}
