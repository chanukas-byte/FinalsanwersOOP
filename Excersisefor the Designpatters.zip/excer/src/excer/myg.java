package excer;

public class myg {

	public static void main(String[] args) {
		
		Mygen<Integer>mg=  new Mygen<>();
		
		
		mg.add(76);
		
		
		mg.add(76);
		
		mg.add(76);
		mg.add(76);
		 
		
		System.out.println(mg);
		
		

	}

}
