package Q2frame;

public class Employee <T,E> {
	
	
	 T empid;
	 E name;
	 
	public Employee(T empid, E name) {
		super();
		this.name = name;
		this.empid = empid;
	}

	public E getName() {
		return name;
	}

	public void setName(E name) {
		this.name = name;
	}

	public T getEmpid() {
		return empid;
	}

	public void setEmpid(T empid) {
		this.empid = empid;
	}
	
	
	public void display()
	{
	System.out.println("empid:"+this.empid);
	System.out.println("name:"+this.name);
	
}	 }
	
	


