package excer;

import java.util.HashMap;
import java.util.Map;

public class hm {

	
	//ascending  order 
	public static void main(String[] args) {
		Map<Integer,String>kk = new HashMap<>();
		kk.put(2,"amal");
		
		kk.put(4, "amal");
		
		kk.put(4, "kusum");
		
		
		//using entry set
		
		/*for (Map.Entry<Integer, String> entry : kk.entrySet()) {
	            System.out.println(entry.getKey() + ", " + entry.getValue());
	        }
	    }
	*/
		
		
		for(Map.Entry<Integer, String > entry:kk.entrySet())
			
				{System.out.println(entry.getKey()+","+entry.getValue());
		
				}
	
		
	}


}