package Q2generic;

/*public class Inventorymanagerapp {

	public static void main(String[] args) {
		
		
		Integer []  intarray= {9,8,3,4};
		System.out.println("minimum is:"+calculateMinimum(intarray));
		
		Double [] doublearray= {45.87,90.98};
		System.out.println("minimum is:"+calculateMinimum(doublearray));

	


}

}*/