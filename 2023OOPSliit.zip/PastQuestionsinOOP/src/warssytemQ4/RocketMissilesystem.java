package warssytemQ4;

public class RocketMissilesystem implements MissileSystem {

	
	
	
	
	private static  RocketMissilesystem  instance=null;
	
	private RocketMissilesystem ()
	{
		System.out.println("initilize the RocketMissile system");
		
	}
	
	
	public static RocketMissilesystem getinstance()
	{
		if(instance==null)
		{
			synchronized(RocketMissilesystem.class)
			{
				if(instance==null)
				{
					 instance= new RocketMissilesystem (); 
				}
			}
		}
		
		
		
		return  instance;
	}
	
	
	
	
	
	
	
	
	
	
	@Override
	public void launch(String location) {
		System.out.println("Rocketmissile is launching "+location);
		
		
	}

	@Override
	public void blast(String destination) {
		
		System.out.println("Rocketmissile blast at "+destination);
		
	}

}
