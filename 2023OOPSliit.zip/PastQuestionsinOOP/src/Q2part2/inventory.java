package Q2part2;

import java.util.HashMap;
import java.util.Map;

public class inventory {
	
	
	 private HashMap<String,Product> inv =new HashMap<>();

	 
	 
	 
	public inventory() {
		super();
		this.inv = inv;
	}
	 
	





	public void addproduct(String productcode,String name,int quantityinstock,double priceperunit)
	{
		inv.put(productcode, null);
	}
	
	
	
	public Product getproduct(String productcode)
	{
		return inv.get(productcode);
		
		
	}
	
	
	public void removeproduct(String productcode)
	{
		inv.remove(productcode);
	}

	
	 public void displayallproducts()
	 {
		 for(Map.Entry<String, Product> Entry:inv.entrySet()) 
		 {
			 System.out.println("keyis:"+Entry.getKey()+"values are"+Entry.getValue());
			 
		 }
	 }
}
