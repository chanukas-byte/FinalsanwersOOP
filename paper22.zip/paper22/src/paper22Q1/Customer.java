package paper22Q1;

abstract public class Customer {

	
	
	int id;
	String name;
	
	
	
	public Customer(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	
	
	 public void display()
	 {
		 System.out.println("id is"+this.id);
		 System.out.println("Customer nameis"+this.name);
		 
	 }
	
	 abstract public double calculatebill();
	 
}
