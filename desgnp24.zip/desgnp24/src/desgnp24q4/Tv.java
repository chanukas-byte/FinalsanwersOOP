package desgnp24q4;

public class Tv  {

	public void turnon() {
		System.out.println("tv is on");
		
		
	}
	
	 public void turnoff()
	{
		System.out.println("tv is off");
		
	}
	
	  public void setchannel(int channel)
	{
		System.out.println("channel number is"+channel);
		
		
		
	}
	
	
}
