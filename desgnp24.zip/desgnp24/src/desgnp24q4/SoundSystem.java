package desgnp24q4;

public class SoundSystem {
	
	
	void turnon()
	{
		System.out.println("turning on soundsystem");
		
	}

	
	void turnoff()
	{
		
		System.out.println("turning off soundsystem");
		
	}
	
	void increasedvolume()
	{

		System.out.println("increasing volume");
		
		
		
	}
}
