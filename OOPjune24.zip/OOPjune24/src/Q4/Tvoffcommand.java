package Q4;

public class Tvoffcommand  implements Command {

	Television tv;
	
	public Tvoffcommand(Television tv) {
		super();
		this.tv = tv;
	}

	@Override
	public void Execute() {
		tv.turnoff();
		
	}

}
