 package Q3;

public class Satelite  extends Thread
{
	
	
	public void run()
	{
		
		
		try {
			for(int i=0;i<5;i++)
			{
				System.out.println("satelite is observing");
				
				
				Thread.sleep(500);
			}
			
			}catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			
		}

	}


