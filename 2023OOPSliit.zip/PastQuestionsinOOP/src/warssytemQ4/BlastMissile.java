package warssytemQ4;

public class BlastMissile implements MissileOperation {

	@Override
	public void initiateOperation(String location) {
		
		
		System.out.println("blastmissile is opeation"+location);
		
		
	}
	
	
	

}
