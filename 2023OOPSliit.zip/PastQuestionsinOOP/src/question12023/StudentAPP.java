package question12023;

import java.util.ArrayList;

public class StudentAPP {

	public static void main(String[] args) {
		
	
		
		ArrayList<Student> students= new ArrayList<>();
		ArrayList<Course> Courses= new ArrayList<>();
		
		
		Student s1 = new Student("e001","chama","galle","070-3456721");
		
		Student s2 = new Student("e002","chamath","kegalle","077-3456721");
		
		
		s1.read();
		s2.read();
		
		students.add(s1);
		students.add(s2);
		
		
		Course c1 = new Course("c001","datascience","ravindunethsara");
		Course c2 = new Course("c002","computerscience","ravindinethsarani");
		
		
		c1.addStudent(s1);
		c2.addStudent(s2);
		
		
		Courses.add(c1);
		Courses.add(c2);
		
		
		System.out.println("students details");
		
		for(Student st:students)
		{
			System.out.println(st);
			
		}

		
		
       System.out.println("course details");
		
		for(Course  cou:Courses)
		{
			System.out.println(cou);
			
		}
		
	}

}
