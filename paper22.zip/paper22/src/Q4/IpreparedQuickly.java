package Q4;

public interface IpreparedQuickly {
	
	
	
	public void deliverytime();

}
