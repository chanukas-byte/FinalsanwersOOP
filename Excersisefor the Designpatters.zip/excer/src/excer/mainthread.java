package excer;

public class mainthread  {
 //extends thread 
	
	public static void main(String[] args) {
		
		
		childthread1 ob = new childthread1();
		
		ob.start();
		
		try
		{
			
			
			ob.sleep(4000000);
			
		}catch(InterruptedException  e)
		{
			 e.printStackTrace();
		}
		
	}

}
