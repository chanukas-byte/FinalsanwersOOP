package excer;

import java.util.Set;
import java.util.TreeSet;

public class tree {

	public static void main(String[] args) {
		
		Set <person> nn = new TreeSet<>();
		nn.add(new person(76));
		nn.add(new person(80));
		
		
		for(person al:nn)
		{
			System.out.println(al);
			
		}//this.age> ((Integer)person).geAge())

	}

}
