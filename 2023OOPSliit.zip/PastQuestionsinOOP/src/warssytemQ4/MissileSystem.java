package warssytemQ4;

public interface MissileSystem {

	
	
	public void launch(String location);
	public void blast(String destination);
	
}
