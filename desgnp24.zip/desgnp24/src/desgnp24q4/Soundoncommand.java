package desgnp24q4;

public class Soundoncommand  implements Command{

	SoundSystem sd;
	
	
	
	public Soundoncommand(SoundSystem sd) {
		super();
		this.sd = sd;
	}



	@Override
	public void execute() {
		
		sd.turnon();
		
		
	}

}
