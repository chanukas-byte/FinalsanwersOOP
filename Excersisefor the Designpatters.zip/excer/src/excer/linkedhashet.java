package excer;

import java.util.LinkedHashSet;
import java.util.Set;

public class linkedhashet  {

	public static void main(String[] args) {
		
		Set<person>name= new LinkedHashSet<>();
		
		name.add(new person(34));
		

		name.add(new person(24));

		name.add(new person(14));

		name.add(new person(64));
		
		for(person h:name)
		{
			System.out.println(h);
			
		}
		
}//public boolean equal(Object person)
	{
		/*if(person instance person)
		 * {
		 * return this.age==((person).getAge());
		 * 
		 * else 
		 * {
		 * return false;
		 * 
		 * 
		 * 
		 */
	}
    /*
     * 
     * public int hashcode(Object person)
	  return this.age;
	  */
}