package novQ1_2023;

import java.util.HashMap;
import java.util.Map;

public class product {

	public String getProductcode() {
		return productcode;
	}
	public void setProductcode(String productcode) {
		this.productcode = productcode;
	}




	String productcode;
	
	String name;
	int qty;
	double price;
	
	Map<String,String>Inventory=new HashMap<>();
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	
	public  void addproduct(String productcode,String name,int qty,double price)
	{
		
		
		
		
	}
}
