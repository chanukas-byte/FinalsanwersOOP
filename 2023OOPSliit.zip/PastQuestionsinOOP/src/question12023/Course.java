package question12023;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Course {
	String courseid;
	String cname;
	String instructor;
	
	 public String getCourseid() {
		return courseid;
	}

	private List<Student>enrolledstudents; 
	public Course(String courseid, String name, String instructor) {
		super();
		this.courseid = courseid;
		this.cname = name;
		this.instructor = instructor;
		this.enrolledstudents=new ArrayList<>();
	}
	
	public void read()
	{
		System.out.println("enter the course id");
		Scanner sc = new Scanner(System.in);
		courseid= sc.next();
		
		
		System.out.println("enter the course name");
		cname=sc.next();
		
		System.out.println("enter the name of instructor");
		instructor= sc.next();
		
	}
	
	public void addStudent(Student student)
	{
		enrolledstudents.add(student);
		System.out.println("studentid"+student.getStudentid()+"\t Courseid:"+courseid);
		
	    
	}
	
	public void print()
	{
		for (Student Student:enrolledstudents)
		{
			System.out.print(Student);
		}
	}
	

}
