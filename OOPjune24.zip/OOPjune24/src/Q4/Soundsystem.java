package Q4;

public class Soundsystem  {

	
	public void turnon()
	{
		System.out.println("Soundsystem  is turning on");
		
		
		
	}

	
	public void turnoff()
	{
		System.out.println("SoundSystem is turning off");
		
	}
	
	
	public void increasevolume()
	{
		System.out.println("Soundsystem is volume increased");
		
		
	}


}
