package Q4;

public class Soundoncommand  implements Command{

	
	Soundsystem sd;
	
	@Override
	public void Execute() {
		sd.turnon();
		
	}

	public Soundoncommand(Soundsystem sd) {
		super();
		this.sd = sd;
	}
	

}
