package Q4;

public interface Ipreparedeliciously {
	
	
	
	public void addflavour();
	public double getcost();
	

}
