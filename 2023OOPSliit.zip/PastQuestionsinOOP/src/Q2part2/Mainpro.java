package Q2part2;

public class Mainpro {
	
	
	
	public static void main(String [] args)
	{
	
		
		
		inventory manager= new inventory();
		
		
		manager.addproduct("p001", "mouse", 4, 400.00);
		manager.addproduct("p002", "monitor",3, 44400.00);
		manager.addproduct("P003", "keyboard", 40, 700.00);
		
		manager.addproduct("p004", "USB", 4, 4000.00);
		manager.addproduct("p005", "VGA", 4, 1400.00);
		
		
		
		System.out.println();
		manager.displayallproducts();
		
		
		
		
		
		
		
		
		
	}

}
