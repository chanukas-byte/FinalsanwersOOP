package excer;

public class Genexample {

	public static void main(String[] args) {
		twogen<Integer ,String> tob = new twogen<>(2,"amal");
		
		//generic class example
		
		tob.dsiplay();
		
		int y= tob.getOb();
		System.out.println("value is:"+y);
		
	}

}
