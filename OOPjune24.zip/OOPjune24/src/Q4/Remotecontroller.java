package Q4;

public class Remotecontroller {
	
	
	private static final Command[] Command = null;




	private static Remotecontroller instance=null;
	

		
		
         Command[]command;
		
		private Remotecontroller(int slotcount)
		{
			command=new Command[slotcount];
			for(int i=0;i<slotcount;i++)
			{
				command[i]=null;
			}
	}
		
		public Remotecontroller getinstance(int slotcount)
		{
			
			
			if(instance == null)
			{
				instance =new Remotecontroller(slotcount);
			}
			return instance;
			
		}

		
		public void setcommand(int slot,Command command)
		
		{
			Command[slot]=command;
		}
}
