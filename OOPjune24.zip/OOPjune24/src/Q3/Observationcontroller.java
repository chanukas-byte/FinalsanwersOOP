package Q3;

public class Observationcontroller {

	public static void main(String[] args) {
		
		
		Thread Telescope = new Telescope();
		Thread Satalite = new Thread();
		
		
		Telescope.start();
		
		try
		{
			Telescope.join();
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		Satelite satelite = new Satelite();
		satelite.start();
		
		
		try
		{
		
			
			satelite.join();
		}catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		
		System.out.println("both are doing simulteniously");
		Telescope tgain= new Telescope ();
		Satelite  st = new Satelite();
		
		tgain.start();
		st.start();
		
		
		
	}

}
