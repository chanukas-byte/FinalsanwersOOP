package desgnp24q4;

public class RemoteController {
	
	    private Command[] commands;

	    
	    public RemoteController(int numberOfSlots) {
	        commands = new Command[numberOfSlots];
	    }

	    
	    public void setCommand(int slot, Command command) {
	        if (slot >= 0 && slot < commands.length) {
	            commands[slot] = command;
	        }
	   
	    
	    
	    }
	    
	    
	    
	    
	    public void pressbutton(int slot)
	    {
	        if (slot >= 0 && slot < commands.length && commands[slot]!=null)
	        {
	        	commands[slot].execute();
	      
	      
	        }
	        else 
	        {
	        	System.out.println("no commands assign for the slot"+slot);
	        	
	        }
	        
	        
	    }
	}

