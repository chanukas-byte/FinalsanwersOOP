package Q12023nov;

public class Student extends Person {

	
	String enrollcourses;
	
	public Student(int id, String name, String enrollcourses) {
		super(id, name);
		this.enrollcourses = enrollcourses;
	}
	
	
	
	
	
	

	public Student(int id, String name) {
		super(id, name);
		this.enrollcourses="";
	}
	



	@Override
	public void displaydetails() {
		
		
	}

	
	public void addcourselist()
	{
	}
	 
	}
		

