package excer;

import java.util.Map;
import java.util.TreeMap;

public class smp {

	public static void main(String[] args) {
		
		
		Map<Integer,String> gg = new TreeMap<>();
		
		
		gg.put(3, "pere");
		gg.put(2, "lalith");
		
		gg.put(1, "frmae");
		
		gg.put(1, "op");
		
		
		//ascending order
		
		
		for(Map.Entry<Integer, String>entry:gg.entrySet()) {
			System.out.println("key is "+entry.getKey()+"value is "+entry.getValue());
			
		}

	}

}
