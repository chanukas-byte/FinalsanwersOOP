package Q3;

public class EvenRunnable  implements Runnable{

	@Override
	public synchronized void run() {
		
		
		for(int nextnum=1;nextnum<20;nextnum++)
		{
			
			
			try
			{
			if(nextnum%2==0)
			{
			
				
				System.out.println("even  numbers running:"+"evennum:"+nextnum+","+Thread.currentThread().getName());
			}
			
			//lock.notify will used for printing separately value
			
			
			
			  Thread.sleep(1000);
			
		   }catch(InterruptedException e)
			
			{
			System.out.println(e.getMessage());
			}
		
	
	}
	}
}

	


	
	


