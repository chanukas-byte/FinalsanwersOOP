package Q3;

public class OddRunnable implements Runnable {

	@Override
	public synchronized void run() {
		// thread safe mode
		
		
		try {
			
			
		for(int nextnum=1;nextnum<20;nextnum++)
		{
			if(nextnum%2!=0)
			{
				System.out.println("even  numbers running:"+"oddnum:"+nextnum+","+Thread.currentThread().getName());
				
			}
		}
		 Thread.sleep(1000);
		
	   }catch (Exception e)
		{
		System.out.println(e.getMessage());
		
		}
	}
}

	


