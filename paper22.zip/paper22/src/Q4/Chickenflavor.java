package Q4;

public class Chickenflavor implements Ipreparedeliciously {

	
	
	private final double cost=100.00;
	
	@Override
	public void addflavour() {
	System.out.println("adding chicken flavor");
		
	}

	@Override
	public double getcost() {
		return cost;
		
		
	}

}
