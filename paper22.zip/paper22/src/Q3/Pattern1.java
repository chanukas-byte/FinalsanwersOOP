package Q3;

public class Pattern1 extends Thread {

	
	
	
	
	 String pattern=null;
	 int count ;
	 
	 
	 
	 public String getPattern() {
		return pattern;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public Object getLock() {
		return lock;
	}

	public void setLock(Object lock) {
		this.lock = lock;
	}

	public Pattern1(String pattern, int count, Object lock) {
		super();
		this.pattern = pattern;
		this.count = count;
		this.lock = lock;
	}

	Object lock;
	
	
	@Override
	public  synchronized void run() {
		
		try {
		for(int i=1;i<=count;i++)
		{
			
			
			
			
			
			System.out.println(Thread.currentThread().getName()+"Threadnumis::"+i);
			printtriangle(i);
			
			Thread.sleep(1000);
		}
		}catch(InterruptedException e)
			{
			e.printStackTrace();
			}
		
	
	}

	
	
		public void printtriangle(int row)
		{
			
			
			
			for(int x=0;x<row;x++)
			{
				
				System.out.println("*");
				
			}
		}
	

}
