package Q2;

public class MainApp {

	public static void main(String[] args) {
		
		Pair<String,Integer>tob= new Pair<>("Test1",42);
		tob.display();
		
		
		System.out.println();
		
		
		
		Pair<Double,String>pob= new Pair<>(3.14,"Test2");
		pob.display();
		
		
		

	}

}
