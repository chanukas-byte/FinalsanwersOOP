package excer;

import java.util.PriorityQueue;
import java.util.Queue;

public class ques {
	
	public static void main(String [] args)
	{
		Queue<Integer> ss = new PriorityQueue<>();
		
		ss.add(3);
		
		
		ss.add(32);
		
		
		ss.add(21);
		
		
		ss.add(309);
		
		
		
		for(Integer ew :ss)
		{
			System.out.println(ew);
			
		}
		
	

	
	
		System.out.println("first element is"+ss.peek());
		
		System.out.println("remove  element is"+ss.poll());
		
		System.out.println("remove  element is"+ss.poll());
		
		
		
		
	}
}
