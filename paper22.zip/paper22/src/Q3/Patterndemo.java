package Q3;

public class Patterndemo  {
	
	
	
	public static void main(String  []args)
	{
	Object lock= new Object();
	
	
	Pattern1 thread = new Pattern1("triangle",10,lock);
	thread.setPattern("pattern thread1");
	
	thread.start();
	
	
	
	
	
	}
	  
	
	

}
