package Q4;

public class Soundoffcommand  implements Command{

	
	Soundsystem sd;
	
	public Soundoffcommand(Soundsystem sd) {
		super();
		this.sd = sd;
	}

	@Override
	public void Execute() {
		
		sd.turnoff();
		
		
	}

}
