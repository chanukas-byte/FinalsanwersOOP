package warssytemQ4;

//singleton method

public class HeatMissileSystem  implements MissileSystem{

	
	private static HeatMissileSystem instance=null;
	
	
	private HeatMissileSystem()
	{
		System.out.println("initilize the heatMissile system");
		
	}
	
	
	
	 public static  HeatMissileSystem getinstance()
	 {
		 
		 //thread Safe double Check
		 
		 if(instance ==null)
		 {
			 synchronized(HeatMissileSystem.class)
			 {
				 if(instance ==null)
				 {
					 instance= new HeatMissileSystem();
				 }
			 }
		 }
		return instance;
		 
	 }
	
	
	
	
	@Override
	public void launch(String location) {
		System.out.println("Heatmissille is launching "+location);
		
	}

	@Override
	public void blast(String destination) {
		
		
		System.out.println("Heatmissile blast at "+ destination);
		
	}

}
