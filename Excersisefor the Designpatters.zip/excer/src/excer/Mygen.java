package excer;

public class Mygen<T> {

	public void add(int i) {
		// TODO Auto-generated method stub
		
	}

}
