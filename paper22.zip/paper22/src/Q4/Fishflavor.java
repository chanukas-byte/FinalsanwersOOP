package Q4;

public class Fishflavor implements Ipreparedeliciously {

	
	
	private  final double cost=80.00;
	
	@Override
	public void addflavour() {
		System.out.println("fish flavor added");
		
	}

	@Override
	public double getcost() {
		// TODO Auto-generated method stub
		return cost;
	}

}
