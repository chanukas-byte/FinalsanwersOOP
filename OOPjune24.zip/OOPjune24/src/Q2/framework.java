package Q2;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class framework {
	
	public static void main(String[]args)
	{
	
	HashMap<Integer,Integer>product= new HashMap<>();
	
	
	while(true)
	{
	System.out.println("enter the product code");
	Scanner sc= new Scanner(System.in);
	int productID= sc.nextInt();
	System.out.println("enter the product quantity");
	int qty=sc.nextInt();
	

	if (qty==99)
	{
		break;
	}
	
	      product.put(productID, qty);

}
	
	System.out.println("enter you want remove product");
     Scanner scx = new Scanner(System.in);
	  
     
     int remo=scx.nextInt();
     
       if(product.containsKey(remo));
       {
    	   product.remove(remo);
    	   System.out.println("successfully removed"+remo);
       }
   
       {
    	   System.out.println("no any matches with your found things");
       }
	
       System.out.println("total noof product in here:"+product.size());
       
       
       for (Map.Entry<Integer, Integer> Entry:product.entrySet())
    	   
       {
    	   System.out.println("productid is:"+Entry.getKey()+"\t"+"product qty is"+Entry.getValue());
    	   
       }
       
       
}}

