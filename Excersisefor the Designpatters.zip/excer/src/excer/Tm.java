package excer;

import java.util.Map;
import java.util.TreeMap;

public class Tm {
	
	public static void main(String [] args)
	{
		
	
	
	Map <Integer,String>ll=  new TreeMap<>();
	
	ll.put(4,"pop");
	
	ll.put(5,"popi");
	ll.put(22,"pol");
	ll.put(40,"pom");
	
	
	//entry set
	
	for(Map.Entry<Integer, String> entry:ll.entrySet())
	{
		System.out.println(entry.getKey()+","+entry.getValue());
		
	}
{
	
}
	
	
	/*
	 * 
		for(Map.Entry<Integer, String > entry:kk.entrySet())
			
				{System.out.println(entry.getKey()+","+entry.getValue());
		
				}
	
	 */

}
}

