package Q2;

public class Pair<T, U> {

	T first;
	U sec;
	
	
	public Pair(T first, U sec) {
		super();
		this.first = first;
		this.sec = sec;
	}
	
	
	public T getFirst()
	{
		return first;
	}
	
	
	public U getSecond()
	{
		return sec;
		
	}
	
	
	
	public void display()
	{
		System.out.println("firstvalue:"+first);
		System.out.println("secondvalue:"+sec);
		
	}
	
	
	
	
}
