package excer;
public class threadmy implements Runnable {

    public static void main(String[] args) {
        
        threadmy myRunnable = new threadmy();
        
       
        Thread ob1 = new Thread(myRunnable);
        ob1.start();
        
        
        Thread ob4 = new Thread(new threadmy());
        ob4.start();
    }

    @Override
    public  synchronized void run() {
    	try
    	{
    		
    	
        for (int i = 0; i < 10; i++) 
        {   Thread.sleep(1000);
            System.out.println("Hello from thread " + Thread.currentThread().getName());
        }
        
        
    }catch(Exception e)
    	{
    	System.out.println("exeception found");
    	
    	}
}
}