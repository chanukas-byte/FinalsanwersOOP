package warssytemQ4;

public class Blastcommand  implements Command{

	MissileSystem missilesystem ;
	String destination;
	 
	
	
	
	public Blastcommand(MissileSystem missilesystem, String destination) {
		super();
		this.missilesystem = missilesystem;
		this.destination = destination;
	}



	

	@Override
	public void execute() {
		
		missilesystem.blast(destination);
	}

}
