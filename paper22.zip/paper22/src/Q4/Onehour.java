package Q4;

public class Onehour  implements IpreparedQuickly{

	@Override
	public void deliverytime() {
		System.out.println("delivering one hour");
		
	}

}
