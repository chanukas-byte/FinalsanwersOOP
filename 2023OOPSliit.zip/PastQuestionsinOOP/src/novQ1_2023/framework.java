package novQ1_2023;

import java.util.PriorityQueue;
import java.util.Scanner;

public class framework {

	
	public static void main(String [] args) {
	
	PriorityQueue<String>bookname= new PriorityQueue<>();
	
	
	
	
	while(true)
	{
		
		System.out.println("Enter the Title of books:");
		Scanner sc = new Scanner(System.in);
		String bname= sc.next();
		
		if(bname.equalsIgnoreCase("done"))
		{
			break;
		}
		
		bookname.add(bname);
		
	}
	
	
	
	
		System.out.println("what kind of book you want remove it");
		Scanner scx = new Scanner (System.in);
		String remobook=scx.next();
		
		  
		if (bookname.contains(remobook))
		{
			
			System.out.println("succesfuly removed it--" +bookname.remove(remobook));
			System.out.println("removed the book title :"+remobook);
			
			
			
		
			
		}else
		{
			System.out.println("Threre any type of that not founded");
		}
		
			
	
	
	   System.out.println("Entire queue length is: "+bookname.size());
	   
	   //printing the allBooks in queue
	   
	   for(String bn:bookname)
	   {
		   System.out.println(bn);
		   
	   }
		
	   
	   
}
}