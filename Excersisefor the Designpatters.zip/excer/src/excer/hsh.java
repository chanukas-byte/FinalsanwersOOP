package excer;

import java.util.HashSet;
import java.util.Set;

public class hsh {
	
	//ascending  order 
	
	public static void main(String [] args)
	{
		Set<Integer>ym = new HashSet<>();
		
		
		ym.add(3);


		ym.add(4);
		

		ym.add(0);
		
		ym.add(0);
		
		
		for(Integer x :ym)
		{
			System.out.println(x);
		}
		
	}

	

}
