package excer;

public class getn {

	public static void main(String[] args) {
		
	}

}
