package excer;

import java.util.Stack;

public class stack {
	
	public static void main(String [] args)
	{
		
		Stack<Integer>qw= new Stack<Integer>();
		qw.push(3);
		
		qw.push(32);
		qw.push(2);
		qw.push(2);
		
		
		
		for(Integer you :qw)
		{
			System.out.println(you);
			
		}
		
		
		//removing lastItem
		
		System.out.println("removing last stack\t"+qw.pop());
		
		
	}

}
