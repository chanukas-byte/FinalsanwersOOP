package excer;

import java.util.LinkedList;
import java.util.List;

public class lls {

	public static void main(String[] args) {
		
		
		List <Integer>ff = new LinkedList<>();
		
		 // order ascending 
		ff.add(40);

		ff.add(03);

		ff.add(322);

		ff.add(2333);
		
		
		
		for(Integer value :ff) {
			System.out.println(value);
			
		}
		

	}

}
