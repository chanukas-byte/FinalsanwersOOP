package Q4;

public class FortyFiveMinutes  implements IpreparedQuickly {

	@Override
	public void deliverytime() {
		System.out.println("delivery by fortyfive minutes");
		
		
	}

}
