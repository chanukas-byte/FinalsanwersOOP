
package excer;

import java.util.ArrayList;

public class Act {

	public static void main(String[] args) {
		

		ArrayList<Integer> marks = new ArrayList<Integer>();
		
		marks.add(45);

		marks.add(35);

		marks.add(25);

		marks.add(85);
		
		
		for(Integer value :marks) {
			System.out.println(value);
			
		}
		

	}

}
