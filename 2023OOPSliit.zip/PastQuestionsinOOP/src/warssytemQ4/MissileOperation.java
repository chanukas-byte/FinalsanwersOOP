package warssytemQ4;

public interface MissileOperation {
	
	public void initiateOperation(String location);
	

}
