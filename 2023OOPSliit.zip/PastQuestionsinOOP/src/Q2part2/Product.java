package Q2part2;

public class Product {
	
	String productname;
	int quantityinstock;
	
	
	
	public Product(String productname, int quantityinstock, double priceperunit) {
		super();
		this.productname = productname;
		this.quantityinstock = quantityinstock;
		this.priceperunit = priceperunit;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public int getQuantityinstock() {
		return quantityinstock;
	}
	public void setQuantityinstock(int quantityinstock) {
		this.quantityinstock = quantityinstock;
	}
	public double getPriceperunit() {
		return priceperunit;
	}
	public void setPriceperunit(double priceperunit) {
		this.priceperunit = priceperunit;
	}
	double priceperunit;
	
	
	public  String toString ()
	{
		return "productname"+productname+"quantitystock"+quantityinstock+"priceperone"+priceperunit;
		
	}
	

}
