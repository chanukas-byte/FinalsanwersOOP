package excer;

public class person {
	
	
	 int age;

	public person(int age) {
		super();
		this.age = age;
	}

}
