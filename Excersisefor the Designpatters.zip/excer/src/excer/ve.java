package excer;

import java.util.Collection;
import java.util.Vector;

public class ve {

	public static void main(String[] args) {
		

		Collection <String> vb = new Vector<>();
		vb.add("gama");
		
		vb.add("sama");
		
		vb.add("ama");
		vb.add("pama");
		
		
		for(String s:vb)
		{
			System.out.println(s);
			
		}

	}

}
