package Q4;

public class Increasedsoundcommand implements Command {

	
	Soundsystem sd;
	
	public Increasedsoundcommand(Soundsystem sd) {
		super();
		this.sd = sd;
	}

	@Override
	public void Execute() {
		sd.increasevolume();
		
	}

}
