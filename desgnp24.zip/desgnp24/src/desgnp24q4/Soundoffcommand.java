package desgnp24q4;

public class Soundoffcommand implements Command {

	SoundSystem sd;
	
	
	
	public Soundoffcommand(SoundSystem sd) {
		super();
		this.sd = sd;
	}



	@Override
	public void execute() {
		sd.turnoff();
	}

}
