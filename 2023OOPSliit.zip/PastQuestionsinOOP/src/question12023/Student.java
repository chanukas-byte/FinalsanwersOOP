package question12023;

import java.util.Scanner;

public class Student {

	
	String Studentid;
	String name;
	String address;
	
	String contactnumber;
	
	public String getStudentid() {
		return Studentid;
	}
	public String getName() {
		return name;
	}


	
	public Student(String studentid, String name, String address, String contactnumber) {
		super();
		Studentid = studentid;
		this.name = name;
		this.address = address;
		this.contactnumber = contactnumber;
	}
	 public void read()
	 {
		 System.out.println("enter the Student id:");
		 
		 
		 Scanner sc = new Scanner(System.in);
		 Studentid=sc.next();
		 
		 
		 
		 System.out.println("enter the Studentname:");
		 name= sc.next();
		 
		 
		 System.out.println("enter the Studentaddress:");
         address= sc.next();
         
         
         
         System.out.println("enter the Studentcontact:");
         contactnumber= sc.next();
		 
		 
		 
	 }
	
	 
	 public void display()
	 {
		 System.out.println("studentinformation");
		 System.out.println("studentid:"+this.Studentid);

		 System.out.println("studentnameis:"+this.name);

		 System.out.println("studentaddress"+this.address);

		 System.out.println("studentcontactnumber"+this.contactnumber);

		 
	 }
}
