package desgnp24q4;

public class Tvoffcommand implements Command {
     
	
	  Tv tv;
	  
	  


		public Tvoffcommand(Tv tv) {
			super();
			this.tv = tv;
		}


	@Override
	public void execute() {
		
	  
		tv.turnoff();
	}

}
