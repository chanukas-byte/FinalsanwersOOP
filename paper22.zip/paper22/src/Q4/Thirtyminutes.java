package Q4;

public class Thirtyminutes implements   IpreparedQuickly {

	@Override
	public void deliverytime() {
		
		
		System.out.println("Deliver  by thirty minutes");
		
	}

}
