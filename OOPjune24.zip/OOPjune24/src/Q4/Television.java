package Q4;

public class Television {
	
	public void turnon()
	{
		System.out.println("tv is turning on");
	}


	public void turnoff()
	{
		System.out.println("tv is turning off");
		
	}

	
	public void setchannel(int channel)
	{
		System.out.println("tv setting channel"+channel);
		
	}

}
	
	
	

