package desgnp24q4;

public class Tvoncommand  implements Command{

	 Tv tv;
	 
	
	

	public Tvoncommand(Tv tv) {
		super();
		this.tv = tv;
	}




	@Override
	public void execute() {
		
		tv.turnon();
		
		
		
		
	}

}
