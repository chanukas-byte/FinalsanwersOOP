package Q4;

public class Eggflavor  implements Ipreparedeliciously{

	
	
	private final double cost =60;
	
	@Override
	public void addflavour() {
		
		
		
       System.out.println("egg flavor added ");
		
	}

	@Override
	public double getcost() {
		return cost;
		
		
	}
	
	
	

}
