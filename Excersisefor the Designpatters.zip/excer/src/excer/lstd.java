
package excer;

import java.util.LinkedList;
import java.util.List;

public class lstd {

	public static void main(String []args)
	{
		List<Integer>qq= new LinkedList<>();
		
		
		qq.add(3);
		qq.add(34);
		qq.add(2);
		qq.add(1);
		
		
		
		for(Integer lop :qq) {;
		
			System.out.println(lop);
			
		}
	}
}
