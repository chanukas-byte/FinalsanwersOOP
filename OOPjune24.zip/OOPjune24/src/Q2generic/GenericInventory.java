package Q2generic;

public class GenericInventory {
	

	
	public static <T extends Comparable	<T>> T calculateMinimum(T[] array)
	{
		if(array==null||array.length==0)
		{
			System.out.println("array is null");
		}
		T min = array[0];
		
		for (T elem:array)
		{
			if(elem.compareTo(min)<0)
			{
				min=elem;
			
			}
		}
		return min;
		
		
		
		
		
		
		
		
	
	}
	
	
	
	public class Inventorymanagerapp {

		public static void main(String[] args) {
			
			
			Integer []  intarray= {9,8,3,4};
			System.out.println("minimum is:"+calculateMinimum(intarray));
			
			
			
			Double [] doublearray= {45.87,90.98};
			System.out.println("minimum is:"+calculateMinimum(doublearray));

		


	}

	}
	
	
	
	
	
	
	
	
	
	
	
	public static <T extends Number> double  calculateAverage(T[]array)
	{
		double sum=0;
		
	
		for(T e:array)
		{
			sum+=e.doubleValue();
		}
		
		return sum/array.length;
		
		
		
	}
		
		

	
	
	public static void main(String [] args)
	{
		
		
		Double  [] doublearray= {9.32,8.321,3.32,4.76};
		System.out.println("avgis:"+calculateAverage(doublearray));
		
		
	}
}
