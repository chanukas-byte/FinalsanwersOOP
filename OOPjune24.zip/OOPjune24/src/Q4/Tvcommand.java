package Q4;
 
public class Tvcommand implements Command {

	Television tv;

	public Tvcommand(Television tv) {
		super();
		this.tv = tv;
	}

	@Override
	public void Execute() {
		tv.turnon();
	}

}
