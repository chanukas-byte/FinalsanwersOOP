package desgnp24q4;

public class ClientApp {
	
	
	// command design pattern
	
	Tv livingroom= new Tv();
	SoundSystem wardobe = new SoundSystem();
	
	
	Command turn_on= new Tvoncommand(livingroom);
	
	Command turn_off= new Tvoffcommand(livingroom);
	
	
	Command tune= new setchannelcommand(livingroom);
	
	
	
	
	
	Command tuon= new Soundoncommand(wardobe);
	Command tu_off= new Soundoffcommand(wardobe);
	
	
	
	Command inv= new IncreasedVolumecommand(wardobe);
	
	
	
	//RemoteController remote = new RemoteController(5); // Assuming 5 slots

    // Assign commands to remote control slots
   /* remote.setCommand(0, turnonTv);
    remote.pressbutton(5);
    
    remote.setCommand(1, turnoffTv);
    remote.setCommand(2, setChannelTv);
    remote.setCommand(3, turnOnSound);
    remote.setCommand(4, turnOffSound);
	*/
	

	   

	
	

	
}
	
	
	
	
	
	

	
	
	
	


