package paper22Q1;

import java.util.Scanner;

public class Registercustomer  extends Customer{

	
	double rewardpoints;
	double netamount;
	
	
	public Registercustomer(int id, String name,double rewardpoints,double netamount) {
		super(id, name);
		this.rewardpoints=0.0;
		this.netamount=0.0;
		
	}


	
	

	@Override
	public double calculatebill() {
		
		System.out.println("enter the Billamount");
	    Scanner sc= new Scanner(System.in);
	    double usamount=sc.nextDouble();
	    
	    if(usamount>950.00)
	    {
	    	rewardpoints =usamount * 15/100;
	    	netamount= usamount* 7/100;
	    	
	    }
	    
	    
	    
	    
	    
		return netamount;
	}
	
	
	public void display()
	{
		System.out.println("customerid-"+this.id);
		System.out.println("customername-"+this.name);
	
		System.out.println("rewards are- "+this.rewardpoints);
		System.out.println("totalamount-"+this.netamount);
		
	}

}
