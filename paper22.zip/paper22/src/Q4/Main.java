package Q4;

public class Main {

	
	public static void main(String[]args)
	{
		
		
		
		Meal breakfast = new Breakfast();
		
		breakfast.displaymeal();
		breakfast.setflavor(new Fishflavor());
		breakfast.setduration(new FortyFiveMinutes());
		breakfast.mealwithflavor();
		breakfast.mealinduration();	
		breakfast.displaycost();
		
		
		System.out.println();
		
		
		
		Meal dinner = new Dinner();
		
		dinner.displaymeal();
		dinner.setflavor(new Eggflavor());
		dinner.setduration(new Onehour());
		dinner.mealwithflavor();
		dinner.displaycost();
		dinner.mealinduration();
		
		
		System.out.println();
		
	
		
		Meal lunch= new Lunch();
		lunch.displaymeal();
		lunch.setflavor(new Chickenflavor());
		lunch.setduration(new Thirtyminutes());
		lunch.mealinduration();
		lunch.mealwithflavor();
		lunch.displaycost();
		
		
		
		

		System.out.println();
		
		Meal breakfast1 =new Breakfast();
		breakfast1.displaymeal();
		breakfast1.setflavor(new Eggflavor());
		breakfast1.setduration(new Onehour());
		breakfast1.mealwithflavor();
		breakfast1.mealinduration();
		breakfast1.displaycost();
		
		
	}
}
