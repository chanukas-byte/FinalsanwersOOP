package Q4;

public class settchannelcommand implements Command {

	
	public settchannelcommand(Television tv) {
		super();
		this.tv = tv;
	}
	Television tv;
	@Override
	public void Execute() {
		tv.setchannel(0);
		
	}

}
