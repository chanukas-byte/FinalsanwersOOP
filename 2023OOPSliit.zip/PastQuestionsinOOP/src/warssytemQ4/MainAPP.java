package warssytemQ4;

public class MainAPP {

	public static void main(String[] args) {
		
		
		
		RocketMissilesystem  rocketmissilesystem = RocketMissilesystem.getinstance();
		HeatMissileSystem heatmissilessytem    = 		HeatMissileSystem.getinstance();
		
		
		Command rocketlaunched=  new LaunchCommand(rocketmissilesystem,"colombo");

		Command rokectblast=  new Blastcommand(rocketmissilesystem,"MH370");
		
		
		

		Command heatlaunched=  new LaunchCommand (heatmissilessytem ,"Kandy");

		Command heatblast=  new Blastcommand(heatmissilessytem,"MH390");
		
		
		
		MissileController mc = new MissileController();
		
		
		System.out.println();
		
		mc.setLaunchcommand(rocketlaunched);
		mc.launchmissile();
		
	
		
		
		mc.setBlastcommand(rokectblast);
		mc.blastmissile();
	
		
		System.out.println();
		
		
		mc.setLaunchcommand(heatlaunched);
		mc.launchmissile();
		

		
		mc.setBlastcommand(heatblast);
		mc.blastmissile();
		

	}

}
